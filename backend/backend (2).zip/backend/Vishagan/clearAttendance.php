<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: http://localhost:5173");
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header("Access-Control-Allow-Credentials: true");

include 'DBConnector.php';

class AttendanceClearer {
    private $db;

    public function __construct() {
        $this->db = (new DBConnector())->getConnection();
    }

    public function clearAttendance($child_id) {
        $query = "
            UPDATE attendance
            SET check_in_time = NULL, check_out_time = NULL
            WHERE child_id = ?
        ";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param('i', $child_id);
        return $stmt->execute();
    }
}

$data = json_decode(file_get_contents('php://input'), true);
$child_id = $data['id'];

$clearer = new AttendanceClearer();
$success = $clearer->clearAttendance($child_id);

if ($success) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to clear attendance']);
}

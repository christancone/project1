<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'DbConnector.php';

class ChildDeleter {
    private $conn;

    public function __construct($dbConnection) {
        $this->conn = $dbConnection;
    }

    public function deleteChild($childId) {
        $query = "DELETE FROM children WHERE id = ?";

        if ($stmt = $this->conn->prepare($query)) {
            $stmt->bind_param("i", $childId);
            if ($stmt->execute()) {
                $response = array("status" => "success", "message" => "Record deleted successfully.");
            } else {
                $response = array("status" => "error", "message" => "Failed to delete record.");
            }
            $stmt->close();
        } else {
            $response = array("status" => "error", "message" => "Failed to prepare SQL statement.");
        }
        
        return $response;
    }
}

$database = new DbConnector();
$conn = $database->getConnection();

$deleter = new ChildDeleter($conn);
$data = json_decode(file_get_contents("php://input"));
$childId = $data->child_id;
$response = $deleter->deleteChild($childId);
$database->closeConnection($conn);
echo json_encode($response);
?>

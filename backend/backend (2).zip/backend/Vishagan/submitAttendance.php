<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: http://localhost:5173");
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header("Access-Control-Allow-Credentials: true");

include 'DBConnector.php';

class AttendanceSubmitter {
    private $db;

    public function __construct() {
        $this->db = (new DBConnector())->getConnection();
    }

    public function submitAttendance($child_id, $child_name, $status, $check_in_time, $check_out_time) {
        $query = "
            INSERT INTO attendance_records (child_id, child_name, status, check_in_time, check_out_time)
            VALUES (?, ?, ?, ?, ?)
        ";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param('issss', $child_id, $child_name, $status, $check_in_time, $check_out_time);
        return $stmt->execute();
    }
}

$data = json_decode(file_get_contents('php://input'), true);
$child_id = $data['child_id'];
$child_name = $data['child_name'];
$status = $data['status'];
$check_in_time = $data['check_in_time'];
$check_out_time = $data['check_out_time'];

$submitter = new AttendanceSubmitter();
$success = $submitter->submitAttendance($child_id, $child_name, $status, $check_in_time, $check_out_time);

if ($success) {
    echo json_encode(['status' => 'success']);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Failed to submit attendance']);
}

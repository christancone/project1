<?php
header('Content-Type: application/json');

// Allow requests from your specific origin (replace with your actual frontend URL)
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

// Handle preflight request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit();
}

include 'DBConnector.php';

class AddChild {
    private $conn;

    public function __construct() {
        $db = new DBConnector();
        $this->conn = $db->getConnection();
    }

    public function addChild($data) {
        $parentUsername = $data['parent_username'];
        $attendantName = $data['attendant_name'];
        $childFirstname = $data['child_firstname'];
        $childLastname = $data['child_lastname'];
        $dob = $data['dob'];
        $medicalInfo = $data['medical_info'];
        $parentId = $this->validateParent($parentUsername);
        if (!$parentId) {
            return ["status" => "error", "message" => "Parent username not found or is not a Parent"];
        }

        $attendantId = $this->validateAttendant($attendantName);
        if (!$attendantId) {
            return ["status" => "error", "message" => "Attendant username not found"];
        }

        // Insert Child Data
        return $this->insertChild($childFirstname, $childLastname, $dob, $parentId, $attendantId, $medicalInfo);
    }

    private function validateParent($username) {
        $sql = "SELECT id FROM users WHERE username = ? AND role = 'Parent'";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $parent = $result->fetch_assoc();
        $stmt->close();

        return $parent ? $parent['id'] : false;
    }

    private function validateAttendant($username) {
        $sql = "SELECT id FROM users WHERE username = ? AND role = 'Attendant'";
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        $attendant = $result->fetch_assoc();
        $stmt->close();

        // Return the 'id', not 'attendant_id'
        return $attendant ? $attendant['id'] : false;
    }

    private function insertChild($firstname, $lastname, $dob, $parentId, $attendantId, $medicalInfo) {
        $sql = "INSERT INTO children (firstname, lastname, dob, parent_id, attendant_id, medical_info) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $this->conn->prepare($sql);

        $stmt->bind_param("sssiss", $firstname, $lastname, $dob, $parentId, $attendantId, $medicalInfo);

        if ($stmt->execute()) {
            $stmt->close();
            return ["status" => "success", "message" => "Child details added successfully"];
        } else {

            error_log("Insert Error: " . $this->conn->error);
            $stmt->close();
            return ["status" => "error", "message" => "Error inserting child details: " . $this->conn->error];
        }
    }
}

$data = json_decode(file_get_contents("php://input"), true);
$addChild = new AddChild();
$response = $addChild->addChild($data);
echo json_encode($response);
?>

<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Credentials: true');

require_once 'DBConnector.php';

class MonthDataFetcher
{
    private $dbConnector;

    public function __construct()
    {
        $this->dbConnector = new DBConnector();
    }

    public function getMonthlyData()
    {
        session_start();
        if (!isset($_SESSION['username'])) {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'message' => 'Session expired or not set.']);
            exit;
        }
        $adminUsername = $_SESSION['username'];
        $con = $this->dbConnector->getConnection();

        $sql = "
            SELECT DATE_FORMAT(c.created_at, '%Y-%m') AS month, COUNT(*) AS count
            FROM children c
            JOIN users u ON c.parent_id = u.id
            WHERE u.admin_username = ?
            GROUP BY month
            ORDER BY month
        ";

        $stmt = $con->prepare($sql);
        if (!$stmt) {
            die(json_encode(['status' => 'error', 'message' => 'Query preparation failed: ' . $con->error]));
        }

        $stmt->bind_param('s', $adminUsername);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Format the month to full month names
                $monthNumber = intval(date('m', strtotime($row['month'] . '-01')));
                $monthName = date('F', mktime(0, 0, 0, $monthNumber, 10));

                $data[] = [
                    'month' => $monthName,
                    'value' => (int)$row['count']
                ];
            }
        }
        $stmt->close();
        $this->dbConnector->closeConnection($con);
        echo json_encode($data);
    }
}

$fetcher = new MonthDataFetcher();
$fetcher->getMonthlyData();
?>

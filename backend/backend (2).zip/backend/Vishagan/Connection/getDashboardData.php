<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');


require '../classes/User.php';

session_start();


if (!isset($_SESSION['username'])) {
    echo json_encode(['error' => 'User not logged in']);
    exit();
}

$admin_username = $_SESSION['username'];

$user = new User();

$response = array(
    'totalKids' => $user->getKidsCount($admin_username),
    'sickKids' => $user->getSickKidsCount($admin_username),
    'totalAttendants' => $user->getAttendantsCount($admin_username)
);

echo json_encode($response);
?>

<?php

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");


if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}


session_start();

if (!isset($_SESSION['username'])) {
    echo json_encode(['error' => 'User not logged in']);
    http_response_code(401); // Unauthorized
    exit();
}

require '../classes/User.php';


$user = new User();
$data = $user->getChildren($_SESSION['username']);
error_log($_SESSION['username']);


if ($data) {
    echo json_encode($data);
} else {
    echo json_encode(['error' => 'No data found']); 
    http_response_code(404);
}
?>

<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: http://localhost:5173");
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header("Access-Control-Allow-Credentials: true");

include 'DBConnector.php';

class PastAttendanceFetcher {
    private $db;

    public function __construct() {
        $this->db = (new DBConnector())->getConnection();
    }

    public function fetchAttendanceByDate($date) {
        $query = "
            SELECT child_id, child_name, status, check_in_time, check_out_time
            FROM attendance_records
            WHERE DATE(check_in_time) = ?
        ";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param('s', $date);
        $stmt->execute();
        $result = $stmt->get_result();
        $records = [];

        while ($row = $result->fetch_assoc()) {
            $records[] = $row;
        }

        return $records;
    }
}

$data = json_decode(file_get_contents('php://input'), true);
$date = $data['date'];

$fetcher = new PastAttendanceFetcher();
$records = $fetcher->fetchAttendanceByDate($date);

echo json_encode(['data' => $records]);

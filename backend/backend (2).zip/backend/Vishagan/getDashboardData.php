<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

session_start();

if (!isset($_SESSION['username'])) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Session expired or not set.', 'data' => []]);
    exit;
}

require_once 'DBConnector.php';

class DashboardData {
    private $con;

    public function __construct() {
        $dbConnector = new DBConnector();
        $this->con = $dbConnector->getConnection();
    }

    public function getKidsCount($admin_username) {
        $query = "
            SELECT COUNT(c.id) AS count 
            FROM children c
            JOIN users u ON c.parent_id = u.id 
            WHERE u.admin_username = ?
        ";
        $stmt = $this->con->prepare($query);
        $stmt->bind_param('s', $admin_username);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['count'];
    }
    public function getSickKidsCount($admin_username) {
        $query = "
            SELECT COUNT(c.id) AS count 
            FROM children c
            JOIN users u ON c.parent_id = u.id 
            WHERE c.medical_info IS NOT NULL 
              AND c.medical_info != '' 
              AND LOWER(c.medical_info) != 'none'
              AND u.admin_username = ?
        ";
        $stmt = $this->con->prepare($query);
        $stmt->bind_param('s', $admin_username);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['count'];
    }
    public function getAttendantsCount($admin_username) {
        $query = "
            SELECT COUNT(u.id) AS count 
            FROM users u
            WHERE u.role = 'attendant' 
              AND u.admin_username = ?
        ";
        $stmt = $this->con->prepare($query);
        $stmt->bind_param('s', $admin_username);
        $stmt->execute();
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();
        return $row['count'];
    }
}

$data = new DashboardData();
$adminUsername = $_SESSION['username'];
$response = array(
    'totalKids' => $data->getKidsCount($adminUsername),
    'sickKids' => $data->getSickKidsCount($adminUsername),
    'totalAttendants' => $data->getAttendantsCount($adminUsername)
);
echo json_encode($response);
?>

<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Credentials: true');

session_start();

if (!isset($_SESSION['username'])) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Session expired or not set.']);
    exit;
}

require_once 'DbConnector.php';

class ChildrenData
{
    private $db;

    public function __construct()
    {
        $dbConnector = new DBConnector();
        $this->db = $dbConnector->getConnection();
    }

    public function getChildren($adminUsername)
    {
        $query = "
            SELECT 
                c.id AS child_id, 
                CONCAT(c.firstname, ' ', c.lastname) AS child_name, 
                CONCAT(u.firstname, ' ', u.lastname) AS parent_name, 
                u.address, 
                u.phone_no 
            FROM 
                children c 
            JOIN 
                users u ON c.parent_id = u.id 
            WHERE 
                u.admin_username = ?
        ";

        $stmt = $this->db->prepare($query);
        if ($stmt) {
            $stmt->bind_param('s', $adminUsername);
            $stmt->execute();
            $result = $stmt->get_result();
            $data = $result->fetch_all(MYSQLI_ASSOC);
            return $data;
        }

        return [];
    }
}

$childrenData = new ChildrenData();
$adminUsername = $_SESSION['username'];
$data = $childrenData->getChildren($adminUsername);
echo json_encode($data);
?>

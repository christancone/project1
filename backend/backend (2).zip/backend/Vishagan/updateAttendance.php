<?php
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");
header("Access-Control-Allow-Credentials: true");

include 'DBConnector.php';
$data = json_decode(file_get_contents("php://input"), true);
$child_id = $data['id'] ?? null;
$check_in_time = $data['check_in_time'] ?? null;
$check_out_time = $data['check_out_time'] ?? null;

if (!$child_id || !$check_in_time) {
    echo json_encode(['status' => 'error', 'message' => 'Child ID and check-in time are required.']);
    exit;
}

try {
    $db = (new DBConnector())->getConnection();
    $query = "SELECT id FROM attendance WHERE child_id = ?";
    $stmt = $db->prepare($query);
    $stmt->bind_param('i', $child_id);
    $stmt->execute();
    $result = $stmt->get_result();



        $query = "UPDATE attendance SET check_in_time = ?, check_out_time = ? WHERE child_id = ?";
        $stmt = $db->prepare($query);
        $stmt->bind_param('ssi', $check_in_time, $check_out_time, $child_id);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Attendance saved successfully!']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Error executing the query.']);
    }

    $stmt->close();
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => 'Error saving attendance: ' . $e->getMessage()]);
}
?>

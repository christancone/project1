<?php

class DBConnector
{

    private $host = 'localhost';
    private $dbuser = 'root';
    private $dbpw = '';
    private $dbname = 'tinytoes';


    public function getConnection()
    {
        $con = new mysqli($this->host, $this->dbuser, $this->dbpw, $this->dbname);

        if ($con->connect_error) {

            die('Connection failed: ' . $con->connect_error);
        }

        return $con;
    }
    public function closeConnection($con)
    {

        if ($con) {
            $con->close();
        }
    }
}

?>

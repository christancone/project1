<?php
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: http://localhost:5173");
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header("Access-Control-Allow-Credentials: true");

include 'DBConnector.php';

class AttendanceFetcher {
    private $db;

    public function __construct() {
        $this->db = (new DBConnector())->getConnection();
    }

    public function fetchAttendance($adminUsername) {
        $query = "
          SELECT 
    a.child_id,
    CONCAT(c.firstname, ' ', c.lastname) AS child_name,
    CONCAT(p.firstname, ' ', p.lastname) AS parent_name,
    a.check_in_time,
    a.check_out_time
FROM attendance a
JOIN children c ON a.child_id = c.id
JOIN users p ON c.parent_id = p.id
WHERE p.admin_username = ?

        ";

        $stmt = $this->db->prepare($query);
        if ($stmt) {
            $stmt->bind_param('s', $adminUsername);
            $stmt->execute();
            $result = $stmt->get_result();

            $attendanceData = [];
            while ($row = $result->fetch_assoc()) {
                $attendanceData[] = $row;
            }

            $stmt->close();
            return $attendanceData;
        } else {
            return [];
        }
    }
}


session_start();
if (!isset($_SESSION['id'])) {
    http_response_code(403); // Forbidden
    echo json_encode(['status' => 'error', 'message' => 'Session expired or not set.', 'data' => []]);
    exit;
}

$adminUsername = $_SESSION['username'] ?? null;

if ($adminUsername) {
    // Create an instance of the AttendanceFetcher class
    $fetcher = new AttendanceFetcher();
    $attendanceData = $fetcher->fetchAttendance($adminUsername);
    echo json_encode(['status' => 'success', 'data' => $attendanceData]);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Admin username not found.', 'data' => []]);
}

<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Access-Control-Allow-Credentials: true');

session_start();

if (!isset($_SESSION['username'])) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Session expired or not set.', 'data' => []]);
    exit;
}

require_once 'DBConnector.php';

class BillingDetailsFetcher {
    private $db;

    public function __construct() {
        $this->db = (new DBConnector())->getConnection();
    }

    public function getBillingDetails($adminUsername) {
        $query = "
            SELECT
                b.amount AS totalAmount,
                b.outstanding_amt AS outstandingAmount,
                b.last_paid_date AS lastReceived,
                c.parent_id,
                CONCAT(c.firstname, ' ', c.lastname) AS childrenName
            FROM billing b
            JOIN children c ON b.child_id = c.id
            JOIN users u ON c.parent_id = u.id
            WHERE u.admin_username = ?
        ";

        $stmt = $this->db->prepare($query);
        if ($stmt) {
            $stmt->bind_param('s', $adminUsername);
            $stmt->execute();
            $result = $stmt->get_result();

            $billingDetails = [];
            while ($row = $result->fetch_assoc()) {
                $billingDetails[] = $row;
            }

            $stmt->close();
            return $billingDetails;
        } else {
            return []; // Return an empty array if statement preparation fails
        }
    }
}

// Create an instance of the BillingDetailsFetcher class
$fetcher = new BillingDetailsFetcher();

// Get the admin username from the session
$adminUsername = $_SESSION['username'] ?? null;
if ($adminUsername) {
    $billingDetails = $fetcher->getBillingDetails($adminUsername);
    echo json_encode($billingDetails);
} else {
    echo json_encode(['status' => 'error', 'message' => 'Admin username not found.', 'data' => []]);
}

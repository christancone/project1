<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: http://localhost:5173');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Allow-Credentials: true');


session_start();


if (!isset($_SESSION['username'])) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Session expired or not set.', 'data' => []]);
    exit;
}

require_once 'DBConnector.php';
$db = (new DBConnector())->getConnection();
$adminUsername = $_SESSION['username'];

$query = "
    SELECT 
        c.medical_info, 
        COUNT(*) AS count
    FROM 
        children c
    JOIN 
        users u ON c.parent_id = u.id
    WHERE 
        u.admin_username = ?
    GROUP BY 
        c.medical_info
";

$stmt = $db->prepare($query);
if (!$stmt) {
    die(json_encode(['status' => 'error', 'message' => 'Query preparation failed: ' . $db->error]));
}

$stmt->bind_param('s', $adminUsername);
$stmt->execute();
$result = $stmt->get_result();

$data = [];

while ($row = $result->fetch_assoc()) {
    $data[$row['medical_info']] = (int)$row['count'];
}

$allConditions = ['Fever', 'Asthma', 'Diabetes', 'None'];
foreach ($data as $condition => $count) {
    if (!in_array($condition, $allConditions)) {
        $data['Others'] = ($data['Others'] ?? 0) + $count;
        unset($data[$condition]);
    }
}

foreach ($allConditions as $condition) {
    if (!isset($data[$condition])) {
        $data[$condition] = 0;
    }
}

$stmt->close();
$db->close();
echo json_encode($data);
?>

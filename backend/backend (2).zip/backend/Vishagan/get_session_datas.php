<?php
header("Access-Control-Allow-Origin: http://localhost:5173"); // Ensure it's your frontend's URL
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Credentials: true");

session_start();


if (!isset($_SESSION['id'])) {
    $response = array(
        'status' => 'error',
        'message' => 'Session expired or not set.',
    );
} else {
    $response = array(
        'status' => 'success',
        'data' => array(
            'id' => $_SESSION['id'],
            'role' => $_SESSION['role'] ?? null,
            'email' => $_SESSION['email'] ?? null,
            'username' => $_SESSION['username'] ?? null,
        ),
    );
}

// Return JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>

<?php
// Add necessary CORS headers
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Start session after handling CORS
session_start();
// Check if session is set to avoid errors when session data is missing
if (!isset($_SESSION['username'])) {
    echo json_encode(['error' => 'User not logged in']);
    http_response_code(401);
    exit();
}

// Include necessary files for database connection
require "DBConnector.php";

// Create a new instance of the DBConnector class and get the database connection
$dbConnector = new DBConnector();
$con = $dbConnector->getConnection();

// Check if the request method is GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Retrieve the logged-in admin's username
    $adminUsername = $_SESSION['username'];

    // SQL query to get the admin's id based on the session username
    $sqlAdminId = "SELECT id FROM users WHERE username = ? AND role = 'Admin'";
    $stmt = $con->prepare($sqlAdminId);
    $stmt->bind_param('s', $adminUsername);
    $stmt->execute();
    $result = $stmt->get_result();

    // Fetch the admin ID
    if ($result->num_rows === 1) {
        $admin = $result->fetch_assoc();
        $adminId = $admin['id'];
    } else {
        echo json_encode(['error' => 'Admin not found']);
        http_response_code(404);
        exit();
    }

    // SQL query to get attendants assigned to the logged-in admin
    $sqlAttendants = "SELECT id FROM users WHERE admin_username = ? AND role = 'Attendant'";
    $stmtAttendants = $con->prepare($sqlAttendants);
    $stmtAttendants->bind_param('s', $adminUsername);
    $stmtAttendants->execute();
    $attendantsResult = $stmtAttendants->get_result();

    // Collect all attendant IDs under this admin
    $attendantIds = [];
    while ($row = $attendantsResult->fetch_assoc()) {
        $attendantIds[] = $row['id'];
    }

    if (empty($attendantIds)) {
        echo json_encode(['error' => 'No attendants found for this admin']);
        http_response_code(404);
        exit();
    }

    // Convert attendant IDs to a comma-separated string for the SQL IN clause
    $attendantIdsStr = implode(',', $attendantIds);

    // SQL query to get children details assigned to these attendants
    $sqlChildren = "SELECT id, firstname, lastname, dob, parent_id, medical_info FROM children WHERE attendant_id IN ($attendantIdsStr)";
    $childrenResult = $con->query($sqlChildren);

    $children = [];
    while ($row = $childrenResult->fetch_assoc()) {
        $children[] = $row;
    }

    if (!empty($children)) {
        echo json_encode($children);
    } else {
        echo json_encode(['error' => 'No children found']);
        http_response_code(404);
    }
} else {
    echo json_encode(['error' => 'Invalid request method']);
    http_response_code(405);
}

$dbConnector->closeConnection($con);
?>

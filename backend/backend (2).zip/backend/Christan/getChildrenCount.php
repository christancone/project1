<?php

// Add necessary CORS headers
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Start session after handling CORS
session_start();

// Check if session is set to avoid errors when session data is missing
if (!isset($_SESSION['username'])) {
    echo json_encode(['error' => 'User not logged in']);
    http_response_code(401); // Unauthorized
    exit();
}

// Include necessary classes
require '../classes/User.php';

// Create a new User instance
$user = new User();

// Fetch the count of children using the session username
$count = $user->getChildrenCount($_SESSION['admin_username']);

// Respond with the count or an error message
if ($count !== null) {
    echo json_encode(['count' => $count]); // Send the count back as JSON
} else {
    echo json_encode(['error' => 'Unable to fetch count']); // Handle error
    http_response_code(500); // Internal server error
}


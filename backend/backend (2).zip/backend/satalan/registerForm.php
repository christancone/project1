<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

// Include your mail sending function and database connection
include 'mailotpsend.php';
require_once 'dbtest.php';

// Start the session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

class RegisterForm {
    private $db;

    public function __construct() {
        $this->db = new Database('tinytoes');
    }

    public function handleRequest() {
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $input = json_decode(file_get_contents('php://input'), true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                error_log('Invalid JSON input');
                echo json_encode(['errors' => 'Invalid JSON input']);
                return;
            }

            // Use null coalescing to set defaults
            $firstName = htmlspecialchars($input['firstname'] ?? '');
            $lastName = htmlspecialchars($input['lastname'] ?? '');
            $phoneNumber = htmlspecialchars($input['phone_no'] ?? '');
            $address = htmlspecialchars($input['address'] ?? '');
            $email = filter_var($input['email'] ?? '', FILTER_VALIDATE_EMAIL);
            $password = $input['password'] ?? '';
            $confirmPassword = $input['confirmPassword'] ?? '';
            $adminId = $input['adminId'] ?? null;
            $username = htmlspecialchars($input['username'] ?? '');

            // Validate input
            $errors = [];
            if (empty($firstName)) $errors['firstname'] = 'First name is required.';
            if (empty($lastName)) $errors['lastname'] = 'Last name is required.';
            if (empty($phoneNumber)) $errors['phone_no'] = 'Phone number is required.';
            if (empty($address)) $errors['address'] = 'Address is required.';
            if (empty($email) || !$email) $errors['email'] = 'A valid email is required.';
            if (empty($password)) $errors['password'] = 'Password is required.';
            if ($password !== $confirmPassword) $errors['confirmPassword'] = 'Passwords do not match.';
            if (empty($adminId)) $errors['adminId'] = 'Please select an Admin ID.';
            if (empty($username)) $errors['username'] = 'Username is required.';

            // Check if email already exists
            if ($this->emailExists($email)) {
                $errors['email'] = 'Email already exists. Please use a different email.';
            }

            if (!empty($errors)) {
                echo json_encode(['errors' => $errors]);
                return;
            }

            // Generate OTP and store it in session
            $otp = $this->generateOTP();
            $_SESSION['otp'] = $otp;

            try {
                if (sendEmail($email, $otp)) {
                    // Hash the password
                    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
                    // Store temporary user data
                    $this->storeTemporaryData($firstName, $lastName, $phoneNumber, $address, $email, $hashedPassword, $otp, $adminId, $username);

                    echo json_encode(['message' => 'OTP sent successfully']);
                } else {
                    error_log('Failed to send OTP email');
                    echo json_encode(['errors' => 'Failed to send OTP email']);
                }
            } catch (Exception $e) {
                error_log($e->getMessage());
                echo json_encode(['errors' => 'Error: ' . $e->getMessage()]);
            }
        } else {
            error_log('Invalid request method');
            echo json_encode(['errors' => 'Invalid request method']);
        }
    }

    public function generateOTP() {
        return rand(1000, 9999);
    }

    private function emailExists($email) {
        // Check in temporary_otp table
        $query = "SELECT COUNT(*) FROM temporary_otp WHERE email = ?";
        $stmt = $this->db->getConnection()->prepare($query);
        if ($stmt === false) {
            error_log('Failed to prepare statement for temporary_otp: ' . $this->db->getConnection()->error);
            return false;
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($countTemp);
        $stmt->fetch();
        $stmt->close();

        // Check in users table
        $query = "SELECT COUNT(*) FROM users WHERE email = ?";
        $stmt = $this->db->getConnection()->prepare($query);
        if ($stmt === false) {
            error_log('Failed to prepare statement for users: ' . $this->db->getConnection()->error);
            return false;
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($countMain);
        $stmt->fetch();
        $stmt->close();

        return $countTemp > 0 || $countMain > 0;
    }

    private function storeTemporaryData($firstName, $lastName, $phoneNumber, $address, $email, $hashedPassword, $otp, $adminId, $username) {
        $query = "INSERT INTO temporary_otp (first_name, last_name, phone_no, address, email, password, otp, adminId, username) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $this->db->getConnection()->prepare($query);
        if ($stmt === false) {
            error_log('Failed to prepare statement: ' . $this->db->getConnection()->error);
            echo json_encode(['errors' => 'Failed to prepare statement']);
            return;
        }

        $stmt->bind_param(
            "sssssssss",
            $firstName,
            $lastName,
            $phoneNumber,
            $address,
            $email,
            $hashedPassword,
            $otp,
            $adminId,
            $username
        );

        $result = $stmt->execute();
        if (!$result) {
            error_log('Failed to execute statement: ' . $stmt->error);
            echo json_encode(['errors' => 'Failed to execute statement']);
        }
    }

    public function transferDataToUsers($email) {
        // Get data from temporary_otp table
        $query = "SELECT username, password, email, address, phone_no, first_name, last_name, adminId FROM temporary_otp WHERE email = ?";
        $stmt = $this->db->getConnection()->prepare($query);
        if ($stmt === false) {
            error_log('Failed to prepare statement: ' . $this->db->getConnection()->error);
            return false;
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $tempData = $result->fetch_assoc();
        $stmt->close();

        if ($tempData) {
            // Insert into users table
            $query = "INSERT INTO users (username, password, email, address, phone_no, firstname, lastname, admin_username,role) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Parent')";
            $stmt = $this->db->getConnection()->prepare($query);
            if ($stmt === false) {
                error_log('Failed to prepare statement for users: ' . $this->db->getConnection()->error);
                return false;
            }

            $stmt->bind_param(
                "ssssssss",
                $tempData['username'],
                $tempData['password'],
                $tempData['email'],
                $tempData['address'],
                $tempData['phone_no'],
                $tempData['first_name'],
                $tempData['last_name'],
                $tempData['adminId'] // Ensure this is correctly mapped to the right field
            );

            $result = $stmt->execute();
            if (!$result) {
                error_log('Failed to execute statement for users: ' . $stmt->error);
                return false;
            }

            // Optionally, delete from temporary_otp after successful transfer
            $this->deleteTemporaryData($email);
            return true;
        }
        return false;
    }


    public function deleteTemporaryData($email) {
        $query = "DELETE FROM temporary_otp WHERE email = ?";
        $stmt = $this->db->getConnection()->prepare($query);
        if ($stmt === false) {
            error_log('Failed to prepare statement for deletion: ' . $this->db->getConnection()->error);
            return false;
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->close();
    }
}

// Instantiate the RegisterForm class and handle the request
$registerForm = new RegisterForm();
$registerForm->handleRequest();

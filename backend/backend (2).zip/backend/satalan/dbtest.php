<?php

class Database {

    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $dbname = "tinytoes"; // Default database name
    private $conn;

    public function __construct($dbname = null) {
        if ($dbname) {
            $this->dbname = $dbname;
        }
        $this->connect();
    }

    private function connect() {
        $this->conn = new mysqli($this->host, $this->username, $this->password, $this->dbname);

        if ($this->conn->connect_error) {
            throw new Exception("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function getConnection() {
        return $this->conn;
    }

    public function __destruct() {
        $this->conn->close(); // Close connection on destruction
    }
}

// Table creation and management code is commented out but can be used separately in migration scripts.

?>

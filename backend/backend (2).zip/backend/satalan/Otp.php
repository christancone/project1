<?php

session_start(); // Start the session

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Access-Control-Allow-Credentials: true");

require_once 'dbtest.php'; // Database connection
require_once 'registerForm.php'; // Registration logic

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $input = json_decode(file_get_contents('php://input'), true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        echo json_encode(['errors' => 'Invalid JSON input']);
        return;
    }

    $otp = $input['enteredOtp'] ?? null;
    $email = htmlspecialchars($input['email'] ?? '');

    // Validate input
    $errors = [];
    if (empty($otp)) $errors['otp'] = 'OTP is required.';
    if (empty($email)) $errors['email'] = 'Email is required.';

    if (!empty($errors)) {
        echo json_encode(['errors' => $errors]);
        return;
    }

    // Verify OTP
    if (!isset($_SESSION['otp']) || $_SESSION['otp'] !== $otp) {
        echo json_encode(['errors' => ['otp' => 'Invalid OTP.']]);
        return;
    }

    // If OTP is valid, transfer data to users table
    $registerForm = new RegisterForm();
    try {
        if ($registerForm->transferDataToUsers($email)) {
            echo json_encode(['message' => 'Verification successful']);
        } else {
            echo json_encode(['errors' => ['general' => 'Failed to transfer data to users.']]);
        }
    } catch (Exception $e) {
        error_log('Error transferring data: ' . $e->getMessage());
        echo json_encode(['errors' => ['general' => 'An error occurred. Please try again.']]);
    }
} else {
    echo json_encode(['errors' => 'Invalid request method']);
}

<?php

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set headers for CORS and JSON response
header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

include './dbtest.php';

// Configure and start session
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => false, 'httponly' => true]);
session_start();

// Check if user is authenticated
if (!isset($_SESSION['id'])) {
    echo json_encode(["error" => "User not authenticated"]);
    exit;
}

class DiningManager {
    private $conn;

    public function __construct($db) {
        $this->conn = $db->getConnection();
        if (!$this->conn) {
            throw new Exception("Database connection failed.");
        }
    }

    public function getChildren($parentId) {
        $sqlChild = "SELECT id, firstname, lastname FROM children WHERE parent_id = ?";
        $stmtChild = $this->conn->prepare($sqlChild);
        $stmtChild->bind_param("i", $parentId);

        if (!$stmtChild->execute()) {
            throw new Exception("Failed to retrieve children data: " . $stmtChild->error);
        }

        return $stmtChild->get_result();
    }

    public function getDiningInfo($childId) {
        $sqlDining = "SELECT food, fromtime, totime FROM dining WHERE childID = ?";
        $stmtDining = $this->conn->prepare($sqlDining);
        $stmtDining->bind_param("i", $childId);

        if (!$stmtDining->execute()) {
            throw new Exception("Failed to retrieve dining information: " . $stmtDining->error);
        }

        return $stmtDining->get_result();
    }

    public function determineMealStatus($dining) {
        // Convert time strings to DateTime objects for reliable comparison
        $fromTime = new DateTime($dining['fromtime']);
        $toTime = new DateTime($dining['totime']);

        // Define meal times
        $breakfastStart = new DateTime('08:00:00');
        $breakfastEnd = new DateTime('10:00:00');
        $lunchStart = new DateTime('11:00:00');
        $lunchEnd = new DateTime('14:00:00');

        // Determine meal statuses
        $breakfastStatus = ($fromTime < $breakfastEnd && $toTime > $breakfastStart)
            ? 'Breakfast complete'
            : 'Breakfast not complete';

        $lunchStatus = ($fromTime < $lunchEnd && $toTime > $lunchStart)
            ? 'Lunch complete'
            : 'Lunch not complete';

        return [
            'breakfastStatus' => $breakfastStatus,
            'lunchStatus' => $lunchStatus,
        ];
    }
}

class NapManager {
    private $conn;

    public function __construct($db) {
        $this->conn = $db->getConnection();
        if (!$this->conn) {
            throw new Exception("Database connection failed.");
        }
    }

    public function getNapInfo($childId) {
        $sqlNap = "SELECT from_time, to_time, notes FROM nap WHERE childid = ?";
        $stmtNap = $this->conn->prepare($sqlNap);
        $stmtNap->bind_param("i", $childId);

        if (!$stmtNap->execute()) {
            throw new Exception("Failed to retrieve nap information: " . $stmtNap->error);
        }

        return $stmtNap->get_result();
    }

    public function determineNapStatus($nap) {
        // Convert time strings to DateTime objects
        $fromTime = new DateTime($nap['from_time']);
        $toTime = new DateTime($nap['to_time']);
        $duration = $fromTime->diff($toTime);
        $totalMinutes = ($duration->h * 60) + $duration->i;

        // Determine nap status based on duration
        if ($totalMinutes < 60) {
            return 'Not perfect sleep';
        } elseif ($totalMinutes >= 60 && $totalMinutes < 120) {
            return 'Perfect sleep';
        } elseif ($totalMinutes >= 120) {
            return 'Well sleep';
        }

        return 'Unknown status';
    }
}

// Get the parent ID from session
$userId = $_SESSION['id'];

// Initialize database connection
$dbConnector = new Database('tinytoes');

try {
    // Initialize managers
    $diningManager = new DiningManager($dbConnector);
    $napManager = new NapManager($dbConnector);

    // Fetch children data
    $childrenResult = $diningManager->getChildren($userId);
    $diningData = [];
    $napData = [];

    // Loop through each child
    while ($child = $childrenResult->fetch_assoc()) {
        $childId = $child['id'];

        // Fetch dining information for the child
        $diningResult = $diningManager->getDiningInfo($childId);
        $childDiningInfo = [];

        if ($diningResult->num_rows > 0) {
            while ($dining = $diningResult->fetch_assoc()) {
                $status = $diningManager->determineMealStatus($dining);
                $childDiningInfo[] = [
                    'food' => $dining['food'],
                    'breakfastStatus' => $status['breakfastStatus'],
                    'lunchStatus' => $status['lunchStatus'],
                ];
            }
        }

        // Add dining data to response
        $diningData[] = [
            'firstname' => $child['firstname'],
            'lastname' => $child['lastname'], // Ensure last name is included
            'dining' => $childDiningInfo
        ];

        // Fetch nap information for the child
        $napResult = $napManager->getNapInfo($childId);
        while ($nap = $napResult->fetch_assoc()) {
            $napStatus = $napManager->determineNapStatus($nap);
            $napData[] = [
                'firstname' => $child['firstname'], // Include child's first name
                'lastname' => $child['lastname'], // Include last name for naps
                'from_time' => $nap['from_time'],
                'to_time' => $nap['to_time'],
                'notes' => $nap['notes'],
                'napStatus' => $napStatus,
            ];
        }
    }

    // Return combined data as JSON
    echo json_encode([
        'dining' => $diningData,
        'naps' => $napData,
    ]);

} catch (Exception $e) {
    // Handle errors and return JSON response
    echo json_encode(["error" => $e->getMessage()]);
}

?>

<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => false, 'httponly' => true]);
session_start();

include './dbtest.php';
class DatabaseConnector {
    private $dbName;
    private $connection;

    public function __construct($dbName) {
        $this->dbName = $dbName;
        $this->connect();
    }

    private function connect() {
        $dbConnector = new Database($this->dbName);
        $this->connection = $dbConnector->getConnection();
    }

    public function getConnection() {
        return $this->connection;
    }
}

class SessionManager {
    public function getSessionId() {
        return session_id();
    }

    public function getUserId() {
        return isset($_SESSION['id']) ? $_SESSION['id'] : 8;
    }
}

class ChildInfo {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function fetchChildData($parentId) {
        $query = "SELECT firstname, lastname, dob, medical_info FROM children WHERE parent_id = ?";
        $stmt = $this->db->prepare($query);
        $stmt->bind_param('i', $parentId);
        $stmt->execute();
        $result = $stmt->get_result();
        $data = $result->fetch_all(MYSQLI_ASSOC);
        $stmt->close();
        return $data;
    }
}

class ChildInfoController {
    private $childInfo;

    public function __construct($childInfo) {
        $this->childInfo = $childInfo;
    }

    public function getChildData($parentId) {
        $childData = $this->childInfo->fetchChildData($parentId);
        if ($childData) {
            $this->outputJson($childData);
        } else {
            $this->outputJson(['error' => 'No child data found']);
        }
    }

    private function outputJson($data) {
        echo json_encode($data);
    }
}

$sessionManager = new SessionManager();
$parentId = $sessionManager->getUserId();

if ($parentId) {
    $dbConnector = new DatabaseConnector('tinytoes');
    $conn = $dbConnector->getConnection();

    if ($conn) {
        $childInfo = new ChildInfo($conn);
        $controller = new ChildInfoController($childInfo);
        $controller->getChildData($parentId);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Database connection failed.']);
    }
} else {
    echo json_encode(['error' => 'Not logged in']);
}
?>


<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set CORS headers to allow the correct frontend origin
header("Access-Control-Allow-Origin: http://localhost:5173");  // Adjust port if necessary
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");  // Ensure the response type is JSON


include './dbtest.php';  // Ensure this path is correct

session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => false, 'httponly' => true]);
session_start();

error_log("billing.php session ID: " . session_id());

 if (!isset($_SESSION['id'])) {
     error_log("User ID not found in session.");
     echo json_encode(['error' => 'User ID not found in session.']);
     exit;
 }

// $userId = $_SESSION['id']; 
$userId = $_SESSION['id'];

// Create an instance of the Database class
$dbConnector = new Database('tinytoes');
$conn = $dbConnector->getConnection();

// Check if the database connection is successful
if (!$conn) {
    echo json_encode(['error' => 'Database connection failed.']);
    exit;
}

// Step 1: Get the child ID from the children table where parent_id matches the user's ID
$sqlChild = "SELECT id, firstname, lastname FROM children WHERE parent_id = ?";
$stmtChild = $conn->prepare($sqlChild);
if ($stmtChild === false) {
    echo json_encode(['error' => 'SQL prepare statement error: ' . $conn->error]);
    exit;
}
$stmtChild->bind_param("i", $userId);
$stmtChild->execute();
$resultChild = $stmtChild->get_result();

// Initialize total amounts and data array
$totalAmount = 0;
$totalOutstanding = 0;
$billingData = [];

// Check if any children are found
if ($resultChild->num_rows > 0) {
    // Fetch each child's details
    while ($child = $resultChild->fetch_assoc()) {
        $childId = $child['id'];

        // Step 2: Fetch billing information for the child
        $sqlBilling = "SELECT 
                            b.amount, 
                            b.last_paid_date, 
                            b.last_paid_amount, 
                            b.outstanding_amt, 
                            b.due_date 
                       FROM billing b 
                       WHERE b.child_id = ?";
        $stmtBilling = $conn->prepare($sqlBilling);
        if ($stmtBilling === false) {
            echo json_encode(['error' => 'SQL prepare statement error: ' . $conn->error]);
            exit;
        }
        $stmtBilling->bind_param("i", $childId);
        $stmtBilling->execute();
        $resultBilling = $stmtBilling->get_result();

        // Initialize child billing records
        $childBilling = [];

        // Check if any billing records are returned
        if ($resultBilling->num_rows > 0) {
            // Fetch billing records
            while ($billing = $resultBilling->fetch_assoc()) {
                // Add to totals
                $totalAmount += $billing['amount'];
                $totalOutstanding += $billing['outstanding_amt'];

                // Add billing details to the child record
                $childBilling[] = [
                    'amount' => $billing['amount'],
                    'last_paid_date' => $billing['last_paid_date'],
                    'last_paid_amount' => $billing['last_paid_amount'],
                    'outstanding_amt' => $billing['outstanding_amt'],
                    'due_date' => $billing['due_date']
                ];
            }
        } else {
            // No billing records found
            $childBilling[] = ['message' => 'No billing records found'];
        }

        // Add the child data to the response
        $billingData[] = [
            'firstname' => $child['firstname'],
            'lastname' => $child['lastname'],
            'billing' => $childBilling
        ];
    }

// Prepare the final response
    $response = [
        'billing_data' => $billingData,
        'total_amount' => $totalAmount,
        'total_outstanding' => $totalOutstanding
    ];

    // Send the response as JSON
    echo json_encode($response);

} else {
    // No child found for the user
    echo json_encode(['error' => 'No children found for User ID: ' . $userId]);
}

// Close the database connection
$conn->close();
?>